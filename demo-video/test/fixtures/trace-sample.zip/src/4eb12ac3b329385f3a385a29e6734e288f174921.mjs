import { test, expect } from '@playwright/test';
test('sample', async ({ page }) => {
  await test.step('Open the page', async () => {
    await page.setContent(`<body style="margin:0;background:#fff"><input id=n style="margin:40px;width:200px"><button id=b style="margin:40px">Go</button><p id=done hidden>Done</p>
      <script>b.onclick=()=>{document.body.style.background='#f00';setTimeout(()=>{document.body.style.background='#00f';done.hidden=false},3000)}</script></body>`);
    await page.mouse.move(200, 150);
    await page.waitForTimeout(600);
  });
  await test.step('Type a name', async () => {
    await page.mouse.move(100, 50, { steps: 10 });
    await page.locator('#n').fill('');
    await page.locator('#n').pressSequentially('Ada', { delay: 70 });
  });
  await test.step('Press the button', async () => {
    await page.mouse.move(280, 50, { steps: 10 });
    await page.locator('#b').click();
    await expect(page.locator('#done')).toBeVisible({ timeout: 10000 });
  });
  await test.step('Done', async () => {
    await page.evaluate(() => { document.body.style.background = "#0f0"; });
    for (let i = 1; i <= 20; i++) { await page.mouse.move(200 + i * 5, 150 + i * 3); await page.waitForTimeout(16); }
    await page.waitForTimeout(600);
  });
});
